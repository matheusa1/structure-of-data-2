#pragma once

#include "ilist.h"
#include "hashTable.h"

THED* inserir_n_aleatorios(int n, int m, int seed);
int THED_MaisLonga(THED* TH);
int THED_MaisCurta(THED* TH);
float THED_TamMedio(THED* TH);